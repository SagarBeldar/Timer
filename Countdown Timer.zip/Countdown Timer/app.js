var endDate="24 April 2023 04:43 PM";

document.getElementById("end-Date").innerText=endDate;

var inputs=document.querySelectorAll("input")
 function clock(){
   
        const end= new Date(endDate);
        var now= new Date()
       

        const diff= (end-now)/1000;

         if(diff<0)return;
        //convert into days
        inputs[0].value=Math.floor(diff/3600/24)

       //convert into hours
        inputs[1].value=Math.floor((diff/3600)%24)

       //convert into Minutes
       inputs[2].value=Math.floor((diff/60)%60)

       //c0nvert into seconds
       inputs[3].value=Math.floor(diff%60)
   
    setInterval(() => {
        clock()
    }, 1000);

   
}
 clock()


   
